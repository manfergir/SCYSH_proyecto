/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "common_def.h"
#include "es_wifi.h"
#include "wifi.h"
#include "stm32l4xx_hal_uart.h"
#include "stdio.h"
#include "mqtt_priv.h"
#include "mqtt_priv_config.h"
//#include "transport_interface.h"
#include "stm32l475e_iot01.h"
#include "stm32l475e_iot01_tsensor.h"
#include "stm32l475e_iot01_hsensor.h"
#include "lsm6dsl.h"
#include"stm32l475e_iot01_accelero.h"
#include <string.h>

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define FLAG_DATA_READY 0x00000001U


/*
 * Vasriable para el tipo de nodo
 * 1 == ACELEROMETRO
 * 2 == ENVIRONMENT
 * */
#define NODE_ID 1



//#define PROJECT_TYPE 0
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
DFSDM_Channel_HandleTypeDef hdfsdm1_channel1;

I2C_HandleTypeDef hi2c2;

QSPI_HandleTypeDef hqspi;

RTC_HandleTypeDef hrtc;

SPI_HandleTypeDef hspi3;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart3;

PCD_HandleTypeDef hpcd_USB_OTG_FS;

/*--------------------------------------------- TAREAS COMUNES --------------------------------------------------------*/
/* Definitions for WifiTask */
osThreadId_t WifiTaskHandle;
const osThreadAttr_t WifiTask_attributes = {
  .name = "WifiTask",
  .stack_size = 512 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for MQTT_Task */
osThreadId_t MQTT_TaskHandle;
const osThreadAttr_t MQTT_Task_attributes = {
  .name = "MQTT_Task",
  .stack_size = 1280 * 4,
  .priority = (osPriority_t) osPriorityLow,
};


/*--------------------------------------------- TAREA ACELEROMETRO --------------------------------------------------------*/
#if NODE_ID == NODE_ID_ACCEL
/* Definitions for Accel_Task */
osThreadId_t Accel_TaskHandle;
const osThreadAttr_t Accel_Task_attributes = {
  .name = "Accel_Task",
  .stack_size = 1024 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
#endif


/*--------------------------------------------- TAREA TEMP-HUMEDAD --------------------------------------------------------*/
#if NODE_ID == NODE_ID_ENV
/* Definitions for task_envRead */
osThreadId_t task_envReadHandle;
const osThreadAttr_t task_envRead_attributes = {
  .name = "task_envRead",
  .stack_size = 512 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
#endif

/*--------------------------------------------- COLAS --------------------------------------------------------*/
/* Definitions for qMqttTx */
osMessageQueueId_t qMqttTxHandle;
const osMessageQueueAttr_t qMqttTx_attributes = {
  .name = "qMqttTx"
};
/* Definitions for qCmdRx */
osMessageQueueId_t qCmdRxHandle;
const osMessageQueueAttr_t qCmdRx_attributes = {
  .name = "qCmdRx"
};
/* USER CODE BEGIN PV */

// Variables globales de estado
volatile uint8_t WIFI_IS_CONNECTED = 0;
volatile uint8_t NET_MQTT_OK = 0;

#define SSID     "Nuria"
#define PASSWORD "12345678"
#define WIFISECURITY WIFI_ECN_WPA2_PSK

#define PORT 	80
#define WIFI_WRITE_TIMEOUT 10000
#define WIFI_READ_TIMEOUT 10000
#define LOG(a) printf a

uint8_t Alert_Flag = 0;

/*#define TERMINAL_USE
#ifdef  TERMINAL_USE
#else
#define LOG(a)
#endif*/
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DFSDM1_Init(void);
static void MX_I2C2_Init(void);
static void MX_QUADSPI_Init(void);
static void MX_SPI3_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_USB_OTG_FS_PCD_Init(void);
static void MX_RTC_Init(void);

/*--------------------------------------------- TAREAS COMUNES --------------------------------------------------------*/
void StartWifiTask(void *argument);
void MQTT_TaskFun(void *argument);

/*--------------------------------------------- TAREA ACCEL --------------------------------------------------------*/
#if NODE_ID == NODE_ID_ACCEL
void Accel_Task_Func(void *argument);
#endif

/*--------------------------------------------- TAREA TEMP-HUMEDAD --------------------------------------------------------*/
#if NODE_ID == NODE_ID_ENV
void task_envReadFunc(void *argument);
#endif

/* USER CODE BEGIN PFP */
extern  SPI_HandleTypeDef hspi;
static  uint8_t  IP_Addr[4];
#if defined (TERMINAL_USE)
extern UART_HandleTypeDef hDiscoUart;
#endif /* TERMINAL_USE */


static  uint8_t  IP_Addr[4];

extern ES_WIFIObject_t    EsWifiObj;

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

//void program_alarm_RTC(void)
//{
//  RTC_AlarmTypeDef sAlarm = {0};
//  RTC_TimeTypeDef sTime = {0};
//  RTC_DateTypeDef sDate = {0};
//
//  HAL_RTC_GetTime(&hrtc, &sTime, RTC_FORMAT_BIN);
//  HAL_RTC_GetDate(&hrtc, &sDate, RTC_FORMAT_BIN); // Necesario para desbloquear registros
//
//  sAlarm.AlarmTime.Seconds = sTime.Seconds;
//  sAlarm.AlarmTime.Minutes = sTime.Minutes + 1; // +1 Minutos
//  sAlarm.AlarmTime.Hours = sTime.Hours;
//
//  if (sAlarm.AlarmTime.Minutes >= 60) {
//    sAlarm.AlarmTime.Minutes -= 60;
//    sAlarm.AlarmTime.Hours += 1;
//  }
//  if (sAlarm.AlarmTime.Hours >= 24) {
//    sAlarm.AlarmTime.Hours -= 24;
//  }
//
//  sAlarm.AlarmMask = RTC_ALARMMASK_DATEWEEKDAY;
//  sAlarm.AlarmSubSecondMask = RTC_ALARMSUBSECONDMASK_ALL;
//  sAlarm.AlarmDateWeekDaySel = RTC_ALARMDATEWEEKDAYSEL_DATE;
//  sAlarm.AlarmDateWeekDay = 1;
//  sAlarm.Alarm = RTC_ALARM_A;
//
//  if (HAL_RTC_SetAlarm_IT(&hrtc, &sAlarm, RTC_FORMAT_BIN) != HAL_OK) {
//    Error_Handler();
//  }
//}

void program_alarm_RTC(void)
{
  RTC_AlarmTypeDef sAlarm = {0};
  RTC_TimeTypeDef  sTime  = {0};
  RTC_DateTypeDef  sDate  = {0};

  HAL_RTC_GetTime(&hrtc, &sTime, RTC_FORMAT_BIN);
  HAL_RTC_GetDate(&hrtc, &sDate, RTC_FORMAT_BIN); // obligatorio

  // Desactivar y limpiar por seguridad (evita retriggers)
  HAL_RTC_DeactivateAlarm(&hrtc, RTC_ALARM_A);
  __HAL_RTC_ALARM_CLEAR_FLAG(&hrtc, RTC_FLAG_ALRAF);
  __HAL_RTC_ALARM_EXTI_CLEAR_FLAG();

  // Próximo minuto a segundo 00
  uint8_t nextMin = sTime.Minutes + 1;
  uint8_t nextHr  = sTime.Hours;

  if (nextMin >= 60) { nextMin = 0; nextHr = (nextHr + 1) % 24; }

  sAlarm.AlarmTime.Hours   = nextHr;
  sAlarm.AlarmTime.Minutes = nextMin;
  sAlarm.AlarmTime.Seconds = 0;

  sAlarm.AlarmMask = RTC_ALARMMASK_DATEWEEKDAY;  // NO enmascares seconds/minutes
  sAlarm.AlarmSubSecondMask = RTC_ALARMSUBSECONDMASK_ALL;
  sAlarm.AlarmDateWeekDaySel = RTC_ALARMDATEWEEKDAYSEL_DATE;
  sAlarm.AlarmDateWeekDay = 1;
  sAlarm.Alarm = RTC_ALARM_A;

  if (HAL_RTC_SetAlarm_IT(&hrtc, &sAlarm, RTC_FORMAT_BIN) != HAL_OK)
  {
    Error_Handler();
  }
}


static int wifi_start(void)
{
	uint8_t  MAC_Addr[6];
 /*Initialize and use WIFI module */
  if(WIFI_Init() ==  WIFI_STATUS_OK)
  {
    LOG(("ES-WIFI Initialized.\r\n"));
    if(WIFI_GetMAC_Address(MAC_Addr) == WIFI_STATUS_OK)
    {
      LOG(("> eS-WiFi module MAC Address : %02X:%02X:%02X:%02X:%02X:%02X\r\n",
               MAC_Addr[0],
               MAC_Addr[1],
               MAC_Addr[2],
               MAC_Addr[3],
               MAC_Addr[4],
               MAC_Addr[5]));
    }
    else
    {
      LOG(("> ERROR : CANNOT get MAC address\r\n"));
      return -1;
    }
  }
  else
  {
    return -1;
  }
  return 0;
}



int wifi_connect(void)
{

  wifi_start();

  LOG(("\nConnecting to %s, %s\r\n",SSID,PASSWORD));
  if( WIFI_Connect(SSID, PASSWORD, WIFISECURITY) == WIFI_STATUS_OK)
  {
    if(WIFI_GetIP_Address(IP_Addr) == WIFI_STATUS_OK)
    {
      LOG(("> es-wifi module connected: got IP Address : %d.%d.%d.%d\r\n",
               IP_Addr[0],
               IP_Addr[1],
               IP_Addr[2],
               IP_Addr[3]));
    }
    else
    {
		  LOG((" ERROR : es-wifi module CANNOT get IP address\r\n"));
      return -1;
    }
  }
  else
  {
		 LOG(("ERROR : es-wifi module NOT connected\r\n"));
     return -1;
  }
  return 0;
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DFSDM1_Init();
  MX_I2C2_Init();
  MX_QUADSPI_Init();
  MX_SPI3_Init();
  MX_USART1_UART_Init();
  MX_USART3_UART_Init();
  MX_USB_OTG_FS_PCD_Init();
  MX_RTC_Init();
  /* USER CODE BEGIN 2 */

	printf("--- [BOOT] Forzando Reinicio Fisico del WiFi ---\r\n");

	// Bajar el pin de Reset (Apagar módulo)
	HAL_GPIO_WritePin(GPIOE, GPIO_PIN_8, GPIO_PIN_RESET);
	HAL_Delay(500); // Esperar medio segundo apagado

	// Subir el pin de Reset (Encender módulo)
	HAL_GPIO_WritePin(GPIOE, GPIO_PIN_8, GPIO_PIN_SET);
	HAL_Delay(1000); // Esperar 1s a que arranque su sistema interno

	printf("--- [BOOT] WiFi Reiniciado. Iniciando Kernel... ---\r\n");

  /* USER CODE END 2 */

  /* Init scheduler */
  osKernelInitialize();

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* Create the queue(s) */
  /* creation of qMqttTx */
  qMqttTxHandle = osMessageQueueNew (8, 1060, &qMqttTx_attributes);

  /* creation of qCmdRx */
  qCmdRxHandle = osMessageQueueNew (5, sizeof(SystemCommand_t), &qCmdRx_attributes);

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /*--------------------------------------------- TAREAS COMUNES --------------------------------------------------------*/
  /* creation of WifiTask */
  WifiTaskHandle = osThreadNew(StartWifiTask, NULL, &WifiTask_attributes);

  /* creation of MQTT_Task */
  MQTT_TaskHandle = osThreadNew(MQTT_TaskFun, NULL, &MQTT_Task_attributes);

  /*--------------------------------------------- TAREA ACCEL --------------------------------------------------------*/
  #if NODE_ID == NODE_ID_ACCEL
  /* creation of Accel_Task */
  Accel_TaskHandle = osThreadNew(Accel_Task_Func, NULL, &Accel_Task_attributes);
  #endif

  /*--------------------------------------------- TAREA TEMP-HUMEDAD --------------------------------------------------------*/
  #if NODE_ID == NODE_ID_ENV
  /* creation of task_envRead */
  task_envReadHandle = osThreadNew(task_envReadFunc, NULL, &task_envRead_attributes);
  #endif


  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

  /* Start scheduler */
  osKernelStart();

  /* We should never get here as control is now taken by the scheduler */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure LSE Drive Capability
  */
  HAL_PWR_EnableBkUpAccess();
  __HAL_RCC_LSEDRIVE_CONFIG(RCC_LSEDRIVE_LOW);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSI|RCC_OSCILLATORTYPE_LSE
                              |RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.LSEState = RCC_LSE_ON;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_MSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 40;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }

  /** Enable MSI Auto calibration
  */
  HAL_RCCEx_EnableMSIPLLMode();
}

/**
  * @brief DFSDM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_DFSDM1_Init(void)
{

  /* USER CODE BEGIN DFSDM1_Init 0 */

  /* USER CODE END DFSDM1_Init 0 */

  /* USER CODE BEGIN DFSDM1_Init 1 */

  /* USER CODE END DFSDM1_Init 1 */
  hdfsdm1_channel1.Instance = DFSDM1_Channel1;
  hdfsdm1_channel1.Init.OutputClock.Activation = ENABLE;
  hdfsdm1_channel1.Init.OutputClock.Selection = DFSDM_CHANNEL_OUTPUT_CLOCK_SYSTEM;
  hdfsdm1_channel1.Init.OutputClock.Divider = 2;
  hdfsdm1_channel1.Init.Input.Multiplexer = DFSDM_CHANNEL_EXTERNAL_INPUTS;
  hdfsdm1_channel1.Init.Input.DataPacking = DFSDM_CHANNEL_STANDARD_MODE;
  hdfsdm1_channel1.Init.Input.Pins = DFSDM_CHANNEL_FOLLOWING_CHANNEL_PINS;
  hdfsdm1_channel1.Init.SerialInterface.Type = DFSDM_CHANNEL_SPI_RISING;
  hdfsdm1_channel1.Init.SerialInterface.SpiClock = DFSDM_CHANNEL_SPI_CLOCK_INTERNAL;
  hdfsdm1_channel1.Init.Awd.FilterOrder = DFSDM_CHANNEL_FASTSINC_ORDER;
  hdfsdm1_channel1.Init.Awd.Oversampling = 1;
  hdfsdm1_channel1.Init.Offset = 0;
  hdfsdm1_channel1.Init.RightBitShift = 0x00;
  if (HAL_DFSDM_ChannelInit(&hdfsdm1_channel1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN DFSDM1_Init 2 */

  /* USER CODE END DFSDM1_Init 2 */

}

/**
  * @brief I2C2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C2_Init(void)
{

  /* USER CODE BEGIN I2C2_Init 0 */

  /* USER CODE END I2C2_Init 0 */

  /* USER CODE BEGIN I2C2_Init 1 */

  /* USER CODE END I2C2_Init 1 */
  hi2c2.Instance = I2C2;
  hi2c2.Init.Timing = 0x10D19CE4;
  hi2c2.Init.OwnAddress1 = 0;
  hi2c2.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c2.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c2.Init.OwnAddress2 = 0;
  hi2c2.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c2.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c2.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c2) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Analogue filter
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c2, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Digital filter
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c2, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C2_Init 2 */

  /* USER CODE END I2C2_Init 2 */

}

/**
  * @brief QUADSPI Initialization Function
  * @param None
  * @retval None
  */
static void MX_QUADSPI_Init(void)
{

  /* USER CODE BEGIN QUADSPI_Init 0 */

  /* USER CODE END QUADSPI_Init 0 */

  /* USER CODE BEGIN QUADSPI_Init 1 */

  /* USER CODE END QUADSPI_Init 1 */
  /* QUADSPI parameter configuration*/
  hqspi.Instance = QUADSPI;
  hqspi.Init.ClockPrescaler = 2;
  hqspi.Init.FifoThreshold = 4;
  hqspi.Init.SampleShifting = QSPI_SAMPLE_SHIFTING_HALFCYCLE;
  hqspi.Init.FlashSize = 23;
  hqspi.Init.ChipSelectHighTime = QSPI_CS_HIGH_TIME_1_CYCLE;
  hqspi.Init.ClockMode = QSPI_CLOCK_MODE_0;
  if (HAL_QSPI_Init(&hqspi) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN QUADSPI_Init 2 */

  /* USER CODE END QUADSPI_Init 2 */

}

/**
  * @brief RTC Initialization Function
  * @param None
  * @retval None
  */
static void MX_RTC_Init(void)
{

  /* USER CODE BEGIN RTC_Init 0 */

  /* USER CODE END RTC_Init 0 */

  RTC_TimeTypeDef sTime = {0};
  RTC_DateTypeDef sDate = {0};
  RTC_AlarmTypeDef sAlarm = {0};

  /* USER CODE BEGIN RTC_Init 1 */

  /* USER CODE END RTC_Init 1 */

  /** Initialize RTC Only
  */
  hrtc.Instance = RTC;
  hrtc.Init.HourFormat = RTC_HOURFORMAT_24;
  hrtc.Init.AsynchPrediv = 127;
  hrtc.Init.SynchPrediv = 255;
  hrtc.Init.OutPut = RTC_OUTPUT_DISABLE;
  hrtc.Init.OutPutRemap = RTC_OUTPUT_REMAP_NONE;
  hrtc.Init.OutPutPolarity = RTC_OUTPUT_POLARITY_HIGH;
  hrtc.Init.OutPutType = RTC_OUTPUT_TYPE_OPENDRAIN;
  if (HAL_RTC_Init(&hrtc) != HAL_OK)
  {
    Error_Handler();
  }

  /* USER CODE BEGIN Check_RTC_BKUP */

  /* USER CODE END Check_RTC_BKUP */

  /** Initialize RTC and set the Time and Date
  */
  sTime.Hours = 0x0;
  sTime.Minutes = 0x0;
  sTime.Seconds = 0x0;
  sTime.DayLightSaving = RTC_DAYLIGHTSAVING_NONE;
  sTime.StoreOperation = RTC_STOREOPERATION_RESET;
  if (HAL_RTC_SetTime(&hrtc, &sTime, RTC_FORMAT_BCD) != HAL_OK)
  {
    Error_Handler();
  }
  sDate.WeekDay = RTC_WEEKDAY_MONDAY;
  sDate.Month = RTC_MONTH_JANUARY;
  sDate.Date = 0x1;
  sDate.Year = 0x0;

  if (HAL_RTC_SetDate(&hrtc, &sDate, RTC_FORMAT_BCD) != HAL_OK)
  {
    Error_Handler();
  }

  /** Enable the Alarm A
  */
  sAlarm.AlarmTime.Hours = 0x0;
  sAlarm.AlarmTime.Minutes = 0x0;
  sAlarm.AlarmTime.Seconds = 0x0;
  sAlarm.AlarmTime.SubSeconds = 0x0;
  sAlarm.AlarmTime.DayLightSaving = RTC_DAYLIGHTSAVING_NONE;
  sAlarm.AlarmTime.StoreOperation = RTC_STOREOPERATION_RESET;
  sAlarm.AlarmMask = RTC_ALARMMASK_NONE;
  sAlarm.AlarmSubSecondMask = RTC_ALARMSUBSECONDMASK_ALL;
  sAlarm.AlarmDateWeekDaySel = RTC_ALARMDATEWEEKDAYSEL_DATE;
  sAlarm.AlarmDateWeekDay = 0x1;
  sAlarm.Alarm = RTC_ALARM_A;
//  if (HAL_RTC_SetAlarm_IT(&hrtc, &sAlarm, RTC_FORMAT_BCD) != HAL_OK)
//  {
//    Error_Handler();
//  }
  /* USER CODE BEGIN RTC_Init 2 */

  /* USER CODE END RTC_Init 2 */

}

/**
  * @brief SPI3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI3_Init(void)
{

  /* USER CODE BEGIN SPI3_Init 0 */

  /* USER CODE END SPI3_Init 0 */

  /* USER CODE BEGIN SPI3_Init 1 */

  /* USER CODE END SPI3_Init 1 */
  /* SPI3 parameter configuration*/
  hspi3.Instance = SPI3;
  hspi3.Init.Mode = SPI_MODE_MASTER;
  hspi3.Init.Direction = SPI_DIRECTION_2LINES;
  hspi3.Init.DataSize = SPI_DATASIZE_4BIT;
  hspi3.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi3.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi3.Init.NSS = SPI_NSS_SOFT;
  hspi3.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2;
  hspi3.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi3.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi3.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi3.Init.CRCPolynomial = 7;
  hspi3.Init.CRCLength = SPI_CRC_LENGTH_DATASIZE;
  hspi3.Init.NSSPMode = SPI_NSS_PULSE_ENABLE;
  if (HAL_SPI_Init(&hspi3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI3_Init 2 */

  /* USER CODE END SPI3_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * @brief USB_OTG_FS Initialization Function
  * @param None
  * @retval None
  */
static void MX_USB_OTG_FS_PCD_Init(void)
{

  /* USER CODE BEGIN USB_OTG_FS_Init 0 */

  /* USER CODE END USB_OTG_FS_Init 0 */

  /* USER CODE BEGIN USB_OTG_FS_Init 1 */

  /* USER CODE END USB_OTG_FS_Init 1 */
  hpcd_USB_OTG_FS.Instance = USB_OTG_FS;
  hpcd_USB_OTG_FS.Init.dev_endpoints = 6;
  hpcd_USB_OTG_FS.Init.speed = PCD_SPEED_FULL;
  hpcd_USB_OTG_FS.Init.phy_itface = PCD_PHY_EMBEDDED;
  hpcd_USB_OTG_FS.Init.Sof_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.low_power_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.lpm_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.battery_charging_enable = DISABLE;
  hpcd_USB_OTG_FS.Init.use_dedicated_ep1 = DISABLE;
  hpcd_USB_OTG_FS.Init.vbus_sensing_enable = DISABLE;
  if (HAL_PCD_Init(&hpcd_USB_OTG_FS) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USB_OTG_FS_Init 2 */

  /* USER CODE END USB_OTG_FS_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOE, M24SR64_Y_RF_DISABLE_Pin|M24SR64_Y_GPO_Pin|ISM43362_RST_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, ARD_D10_Pin|SPBTLE_RF_RST_Pin|ARD_D9_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, ARD_D8_Pin|ISM43362_BOOT0_Pin|ISM43362_WAKEUP_Pin|UserLabel_Pin
                          |SPSGRF_915_SDN_Pin|ARD_D5_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, USB_OTG_FS_PWR_EN_Pin|PMOD_RESET_Pin|STSAFE_A100_RESET_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(SPBTLE_RF_SPI3_CSN_GPIO_Port, SPBTLE_RF_SPI3_CSN_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, VL53L0X_XSHUT_Pin|LED3_WIFI__LED4_BLE_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(SPSGRF_915_SPI3_CSN_GPIO_Port, SPSGRF_915_SPI3_CSN_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(ISM43362_SPI3_CSN_GPIO_Port, ISM43362_SPI3_CSN_Pin, GPIO_PIN_SET);

  /*Configure GPIO pins : M24SR64_Y_RF_DISABLE_Pin M24SR64_Y_GPO_Pin ISM43362_RST_Pin ISM43362_SPI3_CSN_Pin */
  GPIO_InitStruct.Pin = M24SR64_Y_RF_DISABLE_Pin|M24SR64_Y_GPO_Pin|ISM43362_RST_Pin|ISM43362_SPI3_CSN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pins : USB_OTG_FS_OVRCR_EXTI3_Pin SPSGRF_915_GPIO3_EXTI5_Pin SPBTLE_RF_IRQ_EXTI6_Pin ISM43362_DRDY_EXTI1_Pin */
  GPIO_InitStruct.Pin = USB_OTG_FS_OVRCR_EXTI3_Pin|SPSGRF_915_GPIO3_EXTI5_Pin|SPBTLE_RF_IRQ_EXTI6_Pin|ISM43362_DRDY_EXTI1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pin : BOTON_Pin */
  GPIO_InitStruct.Pin = BOTON_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(BOTON_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : ARD_A5_Pin ARD_A4_Pin ARD_A3_Pin ARD_A2_Pin
                           ARD_A1_Pin ARD_A0_Pin */
  GPIO_InitStruct.Pin = ARD_A5_Pin|ARD_A4_Pin|ARD_A3_Pin|ARD_A2_Pin
                          |ARD_A1_Pin|ARD_A0_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG_ADC_CONTROL;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : ARD_D1_Pin ARD_D0_Pin */
  GPIO_InitStruct.Pin = ARD_D1_Pin|ARD_D0_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF8_UART4;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : ARD_D10_Pin SPBTLE_RF_RST_Pin ARD_D9_Pin */
  GPIO_InitStruct.Pin = ARD_D10_Pin|SPBTLE_RF_RST_Pin|ARD_D9_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : ARD_D4_Pin */
  GPIO_InitStruct.Pin = ARD_D4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF1_TIM2;
  HAL_GPIO_Init(ARD_D4_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : ARD_D7_Pin */
  GPIO_InitStruct.Pin = ARD_D7_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG_ADC_CONTROL;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(ARD_D7_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : ARD_D13_Pin ARD_D12_Pin ARD_D11_Pin */
  GPIO_InitStruct.Pin = ARD_D13_Pin|ARD_D12_Pin|ARD_D11_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF5_SPI1;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : ARD_D3_Pin */
  GPIO_InitStruct.Pin = ARD_D3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(ARD_D3_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : ARD_D6_Pin */
  GPIO_InitStruct.Pin = ARD_D6_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_ANALOG_ADC_CONTROL;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(ARD_D6_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : ARD_D8_Pin ISM43362_BOOT0_Pin ISM43362_WAKEUP_Pin UserLabel_Pin
                           SPSGRF_915_SDN_Pin ARD_D5_Pin SPSGRF_915_SPI3_CSN_Pin */
  GPIO_InitStruct.Pin = ARD_D8_Pin|ISM43362_BOOT0_Pin|ISM43362_WAKEUP_Pin|UserLabel_Pin
                          |SPSGRF_915_SDN_Pin|ARD_D5_Pin|SPSGRF_915_SPI3_CSN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : LPS22HB_INT_DRDY_EXTI0_Pin LSM6DSL_INT1_EXTI11_Pin ARD_D2_Pin HTS221_DRDY_EXTI15_Pin
                           PMOD_IRQ_EXTI12_Pin */
  GPIO_InitStruct.Pin = LPS22HB_INT_DRDY_EXTI0_Pin|LSM6DSL_INT1_EXTI11_Pin|ARD_D2_Pin|HTS221_DRDY_EXTI15_Pin
                          |PMOD_IRQ_EXTI12_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pins : USB_OTG_FS_PWR_EN_Pin SPBTLE_RF_SPI3_CSN_Pin PMOD_RESET_Pin STSAFE_A100_RESET_Pin */
  GPIO_InitStruct.Pin = USB_OTG_FS_PWR_EN_Pin|SPBTLE_RF_SPI3_CSN_Pin|PMOD_RESET_Pin|STSAFE_A100_RESET_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pins : VL53L0X_XSHUT_Pin LED3_WIFI__LED4_BLE_Pin */
  GPIO_InitStruct.Pin = VL53L0X_XSHUT_Pin|LED3_WIFI__LED4_BLE_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : VL53L0X_GPIO1_EXTI7_Pin LSM3MDL_DRDY_EXTI8_Pin */
  GPIO_InitStruct.Pin = VL53L0X_GPIO1_EXTI7_Pin|LSM3MDL_DRDY_EXTI8_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : PMOD_SPI2_SCK_Pin */
  GPIO_InitStruct.Pin = PMOD_SPI2_SCK_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF5_SPI2;
  HAL_GPIO_Init(PMOD_SPI2_SCK_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : PMOD_UART2_CTS_Pin PMOD_UART2_RTS_Pin PMOD_UART2_TX_Pin PMOD_UART2_RX_Pin */
  GPIO_InitStruct.Pin = PMOD_UART2_CTS_Pin|PMOD_UART2_RTS_Pin|PMOD_UART2_TX_Pin|PMOD_UART2_RX_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF7_USART2;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pins : ARD_D15_Pin ARD_D14_Pin */
  GPIO_InitStruct.Pin = ARD_D15_Pin|ARD_D14_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF4_I2C1;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI1_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(EXTI1_IRQn);

  HAL_NVIC_SetPriority(EXTI9_5_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);

  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

int _write(int file, char *ptr, int len)
{
	int DataIdx;
	for(DataIdx=0; DataIdx<len; DataIdx++)
	{
		ITM_SendChar(*ptr++);
	}
	return len;
}


void SPI3_IRQHandler(void)
{
  HAL_SPI_IRQHandler(&hspi);
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
  switch (GPIO_Pin)
  {
    case (GPIO_PIN_1):
    {
      SPI_WIFI_ISR();
      break;
    }
    case (BOTON_Pin):
    {
      #if NODE_ID == NODE_ID_ACCEL
      osThreadFlagsSet(Accel_TaskHandle,  NOTE_BUTTON_IRQ);
      #elif NODE_ID == NODE_ID_ENV
      osThreadFlagsSet(task_envReadHandle,  NOTE_BUTTON_IRQ);
      #endif

      break;
    }
    case (LSM6DSL_INT1_EXTI11_Pin):
    {
      #if NODE_ID == NODE_ID_ACCEL
      osThreadFlagsSet(Accel_TaskHandle, NOTE_ACCEL_FIFO);
      #endif
      break;
    }

    default:
    {
      break;
    }
  }
}

/*--------------------------------------------- FUNCIONES TEMP-HUMEDAD --------------------------------------------------------*/

void HAL_RTC_AlarmAEventCallback(RTC_HandleTypeDef *hrtc) {


	#if NODE_ID == NODE_ID_ENV
	  osThreadFlagsSet(task_envReadHandle, FLAG_DATA_READY);

	#elif NODE_ID == NODE_ID_ACCEL
	  osThreadFlagsSet(Accel_TaskHandle, NOTE_RTC_WAKEUP);

	#endif
}


/*--------------------------------------------- FUNCIONES ACCE --------------------------------------------------------*/
#if NODE_ID == NODE_ID_ACCEL

/* Timestamp simple (ms desde arranque) */
static uint32_t now_ms(void)
{
  return (uint32_t)HAL_GetTick();
}

static void send_mqtt_msg(const char *topic, const char *payload)
{
  MqttMsg_t m;
  memset(&m, 0, sizeof(m));
  strncpy(m.topic, topic, MSG_TOPIC_SIZE - 1);
  m.topic[MSG_TOPIC_SIZE - 1] = '\0';

  strncpy(m.payload, payload, MSG_PAYLOAD_SIZE - 1);
  m.payload[MSG_PAYLOAD_SIZE - 1] = '\0';
  osMessageQueuePut(qMqttTxHandle, &m, 0, pdMS_TO_TICKS(100));
}

static void build_payload_block(char *dst, size_t dst_sz,
                                uint32_t t0_ms, uint16_t fs_hz,
                                uint16_t seq, uint16_t total,
                                const int16_t *z, uint16_t n)
{
  // JSON compacto y fragmentado:
  // {"t0":123,"fs":52,"s":0,"n":16,"z":[...]}
  size_t off = 0;
  off += (size_t)snprintf(dst + off, dst_sz - off,
                          "{\"t0\":%lu,\"fs\":%u,\"s\":%u,\"n\":%u,\"z\":[",
                          (unsigned long)t0_ms, fs_hz, seq, total);

  for (uint16_t i = 0; i < n && off < dst_sz; i++)
  {
    off += (size_t)snprintf(dst + off, dst_sz - off,
                            (i == 0) ? "%d" : ",%d", (int)z[i]);
  }

  (void)snprintf(dst + off, (off < dst_sz) ? (dst_sz - off) : 0, "]}");
}
#endif


/* USER CODE END 4 */

/* USER CODE BEGIN Header_StartWifiTask */
/**
  * @brief  Function implementing the WifiTask thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_StartWifiTask */
void StartWifiTask(void *argument)
{
  /* USER CODE BEGIN 5 */
	int ret;
	LOG(("--- [WIFI] Tarea iniciada --- \r\n"));

  /* Infinite loop */
  for(;;)
  {
	  if (WIFI_IS_CONNECTED == 0)
	  {
		  LOG(("[WIFI] Llamando a wifi_connect()...\r\n"));

		  // LLAMADA A TU FUNCIÓN (Línea 142 del main.c)
		  // Esta función ya usa el SSID "Manolo" definido arriba.
		  ret = wifi_connect();

		  if (ret == 0)
		  {
			  LOG(("[WIFI] Conexion Exitosa.\r\n"));
			  WIFI_IS_CONNECTED = 1; // Bandera global para MQTT
		  }
		  else
		  {
			  	LOG(("[WIFI] Fallo al conectar. Reintentando en 5s...\r\n"));
			  osDelay(pdMS_TO_TICKS(5000));
		  }

	  }
	  else
	  {
		 // Ya estamos conectados. Dormimos para no saturar la CPU.
		 osDelay(pdMS_TO_TICKS(1000));
	  }

  }
  /* USER CODE END 5 */
}

/* USER CODE BEGIN Header_MQTT_TaskFun */
/**
* @brief Function implementing the MQTT_Task thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_MQTT_TaskFun */
void MQTT_TaskFun(void *argument)
{
  /* USER CODE BEGIN MQTT_TaskFun */

	NetworkContext_t xNetworkContext = { 0 };
	MQTTContext_t xMQTTContext;
	TransportStatus_t xTransportStatus;

	MqttMsg_t msg_out;
	osStatus_t qStatus;

	LOG(("--- [MQTT] Tarea Iniciada ---\r\n"));

  /* Infinite loop */
	for(;;)
	  {
		  // 1. ESPERAR A WIFI
		  while (WIFI_IS_CONNECTED == 0) {
			osDelay(pdMS_TO_TICKS(500));
		  }

		  // 2. CONECTAR AL BROKER
		  LOG(("[MQTT] Conectando al Broker...\r\n"));

		  // Llamada original. Devuelve TransportStatus_t
		  xTransportStatus = prvConnectToServer(&xNetworkContext);

		  if (xTransportStatus != PLAINTEXT_TRANSPORT_SUCCESS) {
			// NOTA: Si prvConnectToServer falla, el codigo original tiene un osDelay de 10s dentro
			// así que tardará en volver aquí.
			LOG(("[MQTT] Error TCP. Reintentando...\r\n"));
			osDelay(pdMS_TO_TICKS(2000));
			continue;
		  }

		  //LOG(("[MQTT] Esperando estabilizacion del hardware...\r\n"));
		  //HAL_Delay(50);

		  // 3. CONECTAR CAPA MQTT
		  // ATENCION: Esta funcion devuelve VOID en la librería original.
		  // Si falla internamente, ejecuta configASSERT() y resetea la placa.
		  // Es el comportamiento esperado del codigo del profesor.
		  prvCreateMQTTConnectionWithBroker(&xMQTTContext, &xNetworkContext);

		  // Si llegamos aquí, asumimos que estamos conectados
		  LOG(("[MQTT] Loop de transmision activo.\r\n"));
		  NET_MQTT_OK = 1;

		  /* Suscripción al topic de control */
		  prvMQTTSubscribeToTopic(&xMQTTContext, pcAlertTopic);   // pcAlertTopic = "SCF/control"

		  // 4. BUCLE DE TRANSMISIÓN
		  while (WIFI_IS_CONNECTED == 1)
		  {
			qStatus = osMessageQueueGet(qMqttTxHandle, &msg_out, NULL, pdMS_TO_TICKS(100));

			if (qStatus == osOK)
			{
			  LOG(("[MQTT] Enviando Topic: %s...\r\n", msg_out.topic));
			  prvMQTTPublishToTopic(&xMQTTContext, msg_out.topic, msg_out.payload);
			}

			// KeepAlive
			MQTTStatus_t xStat = MQTT_ProcessLoop(&xMQTTContext);

			if (xStat != MQTTSuccess)
			{
				 LOG(("[MQTT] Error KeepAlive. Desconectando...\r\n"));
				 break;
			}
		  }

		  // 5. LIMPIEZA
		  NET_MQTT_OK = 0;
		  LOG(("[MQTT] Reiniciando ciclo de conexion...\r\n"));
		  osDelay(pdMS_TO_TICKS(1000));
	  }
  /* USER CODE END MQTT_TaskFun */
}

/* USER CODE BEGIN Header_task_envReadFunc */
/**
* @brief Function implementing the task_envRead thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_task_envReadFunc */
#if NODE_ID == NODE_ID_ENV
void task_envReadFunc(void *argument)
{
  /* USER CODE BEGIN task_envReadFunc */

  uint32_t id_msg = 0;    //Id del mensaje
  uint8_t reason;     //Motivo del mensaje
  float temp;         //Temperatura
  int16_t temp_int;  //Temperatura en un entero
  uint8_t hum;         //Humedad
  uint32_t flag;      //Bandera activada
  MqttMsg_t msg;      //Mensaje MQTT

  if ( BSP_TSENSOR_Init() == TSENSOR_OK )
  {
    printf("Sensor de temperatura inicializado correctamente.\r\n");
  }
  else
  {
    printf("Error en la inicialización del sensor de temperatura.\r\n");
  }

  if ( BSP_HSENSOR_Init() == HSENSOR_OK )
  {
    printf("Sensor de humedad inicializado correctamente.\r\n");
  }
  else
  {
    printf("Error en la inicialización del sensor de humedad.\r\n");
  }

  program_alarm_RTC();

  /* Infinite loop */

  for(;;)
  {
    
    flag = osThreadFlagsWait(  NOTE_BUTTON_IRQ | FLAG_DATA_READY, osFlagsWaitAny, osWaitForever);

    if ( flag == FLAG_DATA_READY )
    {
      reason = 0;   //El mensaje se envía por timeout
      program_alarm_RTC(); //Reinicio del temporizador
    }
    else if ( flag ==  NOTE_BUTTON_IRQ )
    {
      reason = 1;   //El mensaje se envía por solicitud directa (botón)
    }
    else
    {
      reason = 2;   //El mensaje no debería haberse enviado. Aquí no se debería entrar nunca
    }

    temp = BSP_TSENSOR_ReadTemp();
    temp_int = (int16_t) (temp*10);
    hum = (uint8_t) BSP_HSENSOR_ReadHumidity();

    if( (temp_int >= 200) && (Alert_Flag == 0) )
    {
    	Alert_Flag = 1;
    	snprintf(msg.topic, sizeof(msg.topic), pcAlertTopic);
    	snprintf(msg.payload, sizeof(msg.payload), "MODO::CONTINUO");
    	osMessageQueuePut(qMqttTxHandle, &msg, 0, pdMS_TO_TICKS(100));
    }

    if( (temp_int < 200) && (Alert_Flag == 1) )
    {
    	Alert_Flag = 0;
        snprintf(msg.topic, sizeof(msg.topic), pcAlertTopic);
        snprintf(msg.payload, sizeof(msg.payload), "MODO::NORMAL");
        osMessageQueuePut(qMqttTxHandle, &msg, 0, pdMS_TO_TICKS(100));
    }

    snprintf(msg.topic, sizeof(msg.topic), pcTempTopic);
    snprintf(msg.payload, sizeof(msg.payload),
                 "{\"id\":1,\"msg_id\":%ld,\"origen\":\"%d\",\"temp\":%d,\"hum\":%ld}",
                 id_msg,
                 reason,
                 temp_int,
                 hum);
    
    osMessageQueuePut(qMqttTxHandle, &msg, 0, pdMS_TO_TICKS(100));
    id_msg++;

  }
  /* USER CODE END task_envReadFunc */
}
#endif

/* USER CODE BEGIN Header_Accel_Task_Func */
/**
* @brief Function implementing the Accel_Task thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_Accel_Task_Func */
#if NODE_ID == NODE_ID_ACCEL

void Accel_Task_Func(void *argument)
{
  /* USER CODE BEGIN Accel_Task_Func */
  printf("[ACC] Task start (FIFO)\r\n");

  if (BSP_ACCELERO_Init() != ACCELERO_OK)
  {
    printf("[ACC] Init FAIL\r\n");
    for(;;) osDelay(1000);
  }
  printf("[ACC] After Init\r\n");
  program_alarm_RTC();


  uint8_t continuous = 0;

  /* Infinite loop */
  for (;;)
  {
    uint32_t flags = osThreadFlagsWait( NOTE_BUTTON_IRQ | NOTE_RTC_WAKEUP | NOTE_CMD_RX,
                                       osFlagsWaitAny,
                                       osWaitForever);

    if (flags & NOTE_CMD_RX)
    {
      SystemCommand_t cmd;
      while (osMessageQueueGet(qCmdRxHandle, &cmd, NULL, 0) == osOK)
      {
        if (cmd == CMD_START_CONTINUOUS) continuous = 1;
        if (cmd == CMD_STOP_CONTINUOUS)  continuous = 0;
        if (cmd == CMD_FORCE_READ) osThreadFlagsSet(Accel_TaskHandle, NOTE_RTC_WAKEUP);
      }
    }

    if (flags &  NOTE_BUTTON_IRQ) {
        /* Forzar una captura igual que RTC */
        flags |= NOTE_RTC_WAKEUP;
    }

    if (!(flags & NOTE_RTC_WAKEUP))
        continue;

    if (flags & NOTE_RTC_WAKEUP) {
        program_alarm_RTC();
    }

    const uint16_t target       = continuous ? ACC_CONT_SAMPLES : ACC_BLOCK_SAMPLES; // 1024 o 64
    const uint16_t total_chunks = (uint16_t)(target / ACC_BLOCK_SAMPLES);            // 16 o 1
    const uint16_t watermark_samples = ACC_BLOCK_SAMPLES;                            // 64
    const uint16_t watermark_words   = watermark_samples * 3;                        // 192 words

    printf("[ACC] Capture start FIFO mode=%s target=%u\r\n",
           continuous ? "CONT" : "NORMAL", target);

    // Reconfig FIFO
    LSM6DSL_FifoReset();
    LSM6DSL_FifoConfig(watermark_samples);

    // Limpia flag viejo por si hubo un INT justo al configurar
    (void)osThreadFlagsClear(NOTE_ACCEL_FIFO);

    const uint32_t t0_ms = now_ms();

    int16_t z_block_mg[ACC_BLOCK_SAMPLES];
    uint16_t block_fill = 0;
    uint16_t collected  = 0;
    uint16_t seq        = 0;

    while (collected < target)
    {
      // Espera evento FIFO… pero con fallback si se perdió el flanco
      uint32_t r = osThreadFlagsWait(NOTE_ACCEL_FIFO, osFlagsWaitAny, 1500);

      // Lee nivel actual de FIFO
      uint16_t level_words = LSM6DSL_FifoGetLevelWords();

      // Si no llegó interrupción, pero ya hay >= watermark, seguimos igual
      if (r == (uint32_t)osErrorTimeout)
      {
        if (level_words < watermark_words)
        {
          printf("[ACC] TIMEOUT FIFO event, level_words=%u (<%u)\r\n",
                 (unsigned)level_words, (unsigned)watermark_words);
          continue; // seguimos esperando (sin polling agresivo)
        }
        // si >= watermark: procesamos aunque no entró ISR
        printf("[ACC] Missed INT? level_words=%u (>= watermark)\r\n",
               (unsigned)level_words);
      }

      // Consumimos FIFO mientras haya al menos 1 muestra (3 words)
      while (level_words >= 3 && collected < target)
      {
        int16_t x_raw, y_raw, z_raw;
        LSM6DSL_FifoReadXYZRaw(&x_raw, &y_raw, &z_raw);
        level_words -= 3;

        // FS=2G en tu FifoConfig -> mg = raw * 0.061
        int16_t z_mg = (int16_t)((float)z_raw * LSM6DSL_ACC_SENSITIVITY_2G);

        z_block_mg[block_fill++] = z_mg;
        collected++;

        if (block_fill == ACC_BLOCK_SAMPLES)
        {
          char payload[MSG_PAYLOAD_SIZE];

          build_payload_block(payload, sizeof(payload),
                              t0_ms, ACC_FS_HZ,
                              seq, total_chunks,
                              z_block_mg, ACC_BLOCK_SAMPLES);

          printf("[ACC][JSON] %s\r\n", payload);

          send_mqtt_msg(TOPIC_PUB_ACCEL_PREFIX, payload);

          seq++;
          block_fill = 0;
        }
      }
    }

    LSM6DSL_FifoReset();
    printf("[ACC] Done FIFO. collected=%u chunks=%u\r\n",
           (unsigned)collected, (unsigned)seq);
  }
  /* USER CODE END Accel_Task_Func */
}

#endif

/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM6 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM6)
  {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
